package com.app.service;

import java.util.List;

import com.app.customException.EmployeeNotFoundException;
import com.app.entity.Employee;

public interface EmployeeService {

    List<Employee> getAllEmployees();

    Employee getEmployeeById(Long id) throws EmployeeNotFoundException;

    Employee createEmployee(Employee employee);
}

