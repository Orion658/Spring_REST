package com.app.service;

import java.util.List;

import com.app.customException.JobPostingNotFoundException;
import com.app.dto.JobPostingDTO;

public interface JobPostingService {

    Long postJob(JobPostingDTO jobPostingDTO);

    void updateJob(Long jobId, JobPostingDTO updatedJobPostingDTO) throws JobPostingNotFoundException;

    void deleteJob(Long jobId) throws JobPostingNotFoundException;

    List<JobPostingDTO> getAllJobPostings();
}
