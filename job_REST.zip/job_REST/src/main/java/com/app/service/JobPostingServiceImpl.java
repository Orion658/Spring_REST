package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.customException.JobPostingNotFoundException;
import com.app.dao.JobPostingRepository;
import com.app.dto.JobPostingDTO;
import com.app.entity.JobPosting;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

@Service
public class JobPostingServiceImpl implements JobPostingService {

    @Autowired
    private JobPostingRepository jobPostingRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Long postJob(JobPostingDTO jobPostingDTO) {
        JobPosting jobPosting = modelMapper.map(jobPostingDTO, JobPosting.class);
        jobPosting.setPostingDate(LocalDate.now()); // Assuming posting date is set at the time of posting
        jobPostingRepository.save(jobPosting);
        return jobPosting.getId();
    }

    @Override
    public void updateJob(Long jobId, JobPostingDTO updatedJobPostingDTO) throws JobPostingNotFoundException {
        JobPosting existingJobPosting = jobPostingRepository.findById(jobId)
                .orElseThrow(() -> new JobPostingNotFoundException("Job posting not found with ID: " + jobId));

        modelMapper.map(updatedJobPostingDTO, existingJobPosting);
       
        jobPostingRepository.save(existingJobPosting);
    }

    @Override
    public void deleteJob(Long jobId) throws JobPostingNotFoundException {
        JobPosting existingJobPosting = jobPostingRepository.findById(jobId)
                .orElseThrow(() -> new JobPostingNotFoundException("Job posting not found with ID: " + jobId));

        jobPostingRepository.delete(existingJobPosting);
    }

    @Override
    public List<JobPostingDTO> getAllJobPostings() {
        List<JobPosting> jobPostings = jobPostingRepository.findAll();
        return jobPostings.stream()
                .map(jobPosting -> modelMapper.map(jobPosting, JobPostingDTO.class))
                .collect(Collectors.toList());
    }
}

