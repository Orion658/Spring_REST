package com.app.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class JobPosting extends BaseEntity {

 @Column(name = "job_title")
 private String jobTitle;

 @Column(name = "company_name")
 private String companyName;

 private String location;

 private String description;

 private String requirements;

 private double salary;

 @Column(name = "posting_date")
 private LocalDate postingDate;

}

