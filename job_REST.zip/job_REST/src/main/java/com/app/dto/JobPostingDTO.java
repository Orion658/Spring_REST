package com.app.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JobPostingDTO {
    private String jobTitle;
    private String companyName;
    private String location;
    private String description;
    private String requirements;
    private double salary;
    private LocalDate postingDate;
}
