package com.app.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
public class ApiResponse {

    private String message;
    private LocalDateTime timeStamp;
    private List<JobPostingDTO> jobPostings;

    public ApiResponse(String message) {
        this.message = message;
        this.timeStamp = LocalDateTime.now();
    }

    public ApiResponse(String message, List<JobPostingDTO> jobPostings) {
        this.message = message;
        this.timeStamp = LocalDateTime.now();
        this.jobPostings = jobPostings;
    }
}

