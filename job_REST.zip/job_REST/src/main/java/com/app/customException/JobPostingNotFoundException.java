package com.app.customException;

public class JobPostingNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public JobPostingNotFoundException(String e) {
		super(e);
	}

}
