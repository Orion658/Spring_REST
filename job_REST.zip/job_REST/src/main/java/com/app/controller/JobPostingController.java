package com.app.controller;

import java.util.List;

import javax.persistence.EntityNotFoundException;

import com.app.customException.JobPostingNotFoundException;
import com.app.dto.ApiResponse;
import com.app.dto.JobPostingDTO;
import com.app.service.JobPostingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/jobPostings")
public class JobPostingController {

    @Autowired
    private JobPostingService jobPostingService;

    @PostMapping
    public ResponseEntity<ApiResponse> postJob(@RequestBody JobPostingDTO jobPostingDTO) {
        try {
            Long jobId = jobPostingService.postJob(jobPostingDTO);
            String message = "Job posting created successfully. Job ID: " + jobId;
            return new ResponseEntity<>(new ApiResponse(message), HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse(e.getMessage()));
        }
    }

    @PutMapping("/{jobId}")
    public ResponseEntity<ApiResponse> updateJob(@PathVariable Long jobId, @RequestBody JobPostingDTO updatedJobPostingDTO) throws JobPostingNotFoundException {
        try {
            jobPostingService.updateJob(jobId, updatedJobPostingDTO);
            return new ResponseEntity<>(new ApiResponse("Job posting updated successfully."), HttpStatus.OK);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse(e.getMessage()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse(e.getMessage()));
        }
    }

    @DeleteMapping("/{jobId}")
    public ResponseEntity<ApiResponse> deleteJob(@PathVariable Long jobId) throws JobPostingNotFoundException {
        try {
            jobPostingService.deleteJob(jobId);
            return new ResponseEntity<>(new ApiResponse("Job posting deleted successfully."), HttpStatus.OK);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse(e.getMessage()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse(e.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getAllJobPostings() {
        try {
            List<JobPostingDTO> jobPostings = jobPostingService.getAllJobPostings();
            return new ResponseEntity<>(new ApiResponse("Job postings retrieved successfully", jobPostings), HttpStatus.OK);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse(e.getMessage()));
        }
    }
}


