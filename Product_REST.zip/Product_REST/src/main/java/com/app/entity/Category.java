package com.app.entity;

public enum Category {
	FASHION, ELECTRONICS
}
