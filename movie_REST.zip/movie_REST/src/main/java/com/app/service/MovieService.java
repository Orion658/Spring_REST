package com.app.service;

import com.app.dto.MovieDTO;

public interface MovieService {
    Long addMovie(MovieDTO movieDTO);
}
